class Dog:
    def __init__(self, name):
        self.name = name

d = Dog("Lucky")
print(d.name)
